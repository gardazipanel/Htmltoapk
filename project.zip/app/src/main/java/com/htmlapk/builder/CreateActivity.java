package com.htmlapk.builder;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Pattern;

public class CreateActivity extends Activity {

    private static final int REQ_FILE = 1;
    private static final int REQ_ICON = 2;
    private static final int REQ_SAVE = 3;
    private static final Pattern PKG = Pattern.compile("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$");

    private boolean zipMode;
    private Uri sourceUri;
    private byte[] iconPng;
    private File builtApk;
    private boolean pkgEdited;
    private boolean settingPkg;

    private TextView fileNameView;
    private TextView statusView;
    private TextView resultView;
    private EditText nameEdit;
    private EditText pkgEdit;
    private ImageView iconView;
    private Button buildBtn;
    private ProgressBar progress;
    private LinearLayout resultBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        zipMode = "zip".equals(getIntent().getStringExtra("mode"));

        LinearLayout root = Ui.screen(this, zipMode ? "ZIP File to APK" : "HTML File to APK", true);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(false);
        root.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 32));
        sv.addView(col);

        // ----- 1. file -----
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.tv(this, zipMode ? "1. Select ZIP file (website)" : "1. Select HTML file", 17, Ui.TEXT, true));
        if (zipMode) {
            TextView hint = Ui.tv(this, "ZIP ke andar index.html honi chahiye.", 13, Ui.SUB, false);
            hint.setPadding(0, Ui.dp(this, 4), 0, 0);
            c1.addView(hint);
        }
        Button pick = button("Choose file", false);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pick(REQ_FILE, "*/*");
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 48));
        pl.topMargin = Ui.dp(this, 12);
        c1.addView(pick, pl);
        fileNameView = Ui.tv(this, "No file selected", 14, Ui.SUB, false);
        fileNameView.setPadding(0, Ui.dp(this, 8), 0, 0);
        c1.addView(fileNameView);
        col.addView(c1, Ui.margins(this, 0, 0, 0, 12));

        // ----- 2. details -----
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.tv(this, "2. App details", 17, Ui.TEXT, true));
        nameEdit = edit("App name");
        pkgEdit = edit("Package name (com.example.app)");
        pkgEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 50));
        el.topMargin = Ui.dp(this, 12);
        c2.addView(nameEdit, el);
        c2.addView(pkgEdit, el);
        col.addView(c2, Ui.margins(this, 0, 0, 0, 12));

        nameEdit.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (!pkgEdited) {
                    settingPkg = true;
                    pkgEdit.setText(autoPackage(s.toString()));
                    settingPkg = false;
                }
            }
        });
        pkgEdit.addTextChangedListener(new SimpleWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                if (!settingPkg) {
                    pkgEdited = true;
                }
            }
        });

        // ----- 3. icon -----
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.tv(this, "3. App icon (optional)", 17, Ui.TEXT, true));
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        iconView = new ImageView(this);
        iconView.setBackground(Ui.shape(this, 0xFFE5E7EB, 0, 0, 14));
        iconView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iconRow.addView(iconView, new LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)));
        Button iconBtn = button("Choose icon", false);
        iconBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pick(REQ_ICON, "image/*");
            }
        });
        LinearLayout.LayoutParams ib = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f);
        ib.leftMargin = Ui.dp(this, 14);
        iconRow.addView(iconBtn, ib);
        LinearLayout.LayoutParams ir = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        ir.topMargin = Ui.dp(this, 12);
        c3.addView(iconRow, ir);
        col.addView(c3, Ui.margins(this, 0, 0, 0, 16));

        // ----- build -----
        buildBtn = button("BUILD APK", true);
        buildBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startBuild();
            }
        });
        col.addView(buildBtn, new LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 54)));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        pp.topMargin = Ui.dp(this, 16);
        col.addView(progress, pp);

        statusView = Ui.tv(this, "", 14, Ui.SUB, false);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, Ui.dp(this, 8), 0, 0);
        col.addView(statusView);

        // ----- result -----
        resultBox = Ui.card(this);
        resultBox.setVisibility(View.GONE);
        resultView = Ui.tv(this, "", 15, Ui.TEXT, true);
        resultBox.addView(resultView);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button install = button("Install", true);
        install.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (builtApk != null) {
                    Ui.install(CreateActivity.this, builtApk);
                }
            }
        });
        Button save = button("Save a copy", false);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCopy();
            }
        });
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f);
        a1.rightMargin = Ui.dp(this, 6);
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f);
        a2.leftMargin = Ui.dp(this, 6);
        actions.addView(install, a1);
        actions.addView(save, a2);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP);
        al.topMargin = Ui.dp(this, 12);
        resultBox.addView(actions, al);
        col.addView(resultBox, Ui.margins(this, 0, 16, 0, 0));
    }

    // ---------- UI helpers ----------

    private Button button(String text, boolean filled) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        if (filled) {
            b.setTextColor(Color.WHITE);
            b.setBackground(Ui.shape(this, Ui.TEAL, 0, 0, 14));
        } else {
            b.setTextColor(Ui.TEAL);
            b.setBackground(Ui.shape(this, Color.WHITE, Ui.TEAL, 2, 14));
        }
        return b;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(0xFF9CA3AF);
        e.setBackground(Ui.shape(this, Color.WHITE, 0xFFD1D5DB, 1, 12));
        e.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        return e;
    }

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    }

    private static String autoPackage(String name) {
        String s = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (s.length() == 0) {
            s = "app";
        }
        if (Character.isDigit(s.charAt(0))) {
            s = "app" + s;
        }
        return "com.myapp." + s;
    }

    // ---------- picking ----------

    private void pick(int req, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Ui.toast(this, "File picker khul nahi saka");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_FILE) {
            sourceUri = uri;
            String n = displayName(uri);
            fileNameView.setText(n);
            fileNameView.setTextColor(Ui.TEAL);
            if (nameEdit.getText().length() == 0) {
                int dot = n.lastIndexOf('.');
                nameEdit.setText(dot > 0 ? n.substring(0, dot) : n);
            }
        } else if (requestCode == REQ_ICON) {
            loadIcon(uri);
        } else if (requestCode == REQ_SAVE && builtApk != null) {
            try {
                InputStream in = new FileInputStream(builtApk);
                OutputStream out = getContentResolver().openOutputStream(uri);
                try {
                    Ui.copy(in, out);
                } finally {
                    in.close();
                    if (out != null) {
                        out.close();
                    }
                }
                Ui.toast(this, "APK save ho gayi");
            } catch (Exception e) {
                Ui.toast(this, "Save nahi hui: " + e.getMessage());
            }
        }
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) {
                    return n;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) {
                c.close();
            }
        }
        String last = uri.getLastPathSegment();
        return last != null ? last : "file";
    }

    private void loadIcon(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) {
                in.close();
            }
            int sample = 1;
            while (o.outWidth / sample > 1024 || o.outHeight / sample > 1024) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            in = getContentResolver().openInputStream(uri);
            Bitmap bm = BitmapFactory.decodeStream(in, null, o2);
            if (in != null) {
                in.close();
            }
            if (bm == null) {
                Ui.toast(this, "Ye image khul nahi saki");
                return;
            }
            int w = bm.getWidth();
            int h = bm.getHeight();
            int s = Math.min(w, h);
            Bitmap sq = Bitmap.createBitmap(bm, (w - s) / 2, (h - s) / 2, s, s);
            Bitmap icon = Bitmap.createScaledBitmap(sq, 192, 192, true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            icon.compress(Bitmap.CompressFormat.PNG, 100, bos);
            iconPng = bos.toByteArray();
            iconView.setImageBitmap(icon);
        } catch (Exception e) {
            Ui.toast(this, "Icon load nahi hua: " + e.getMessage());
        }
    }

    // ---------- build ----------

    private void startBuild() {
        if (sourceUri == null) {
            Ui.toast(this, zipMode ? "Pehle ZIP file chunen" : "Pehle HTML file chunen");
            return;
        }
        final String appName = nameEdit.getText().toString().trim();
        final String pkg = pkgEdit.getText().toString().trim();
        if (appName.length() == 0) {
            Ui.toast(this, "App ka naam likhen");
            return;
        }
        if (!PKG.matcher(pkg).matches()) {
            Ui.toast(this, "Package name aisa hona chahiye: com.example.myapp (chhote letters, numbers, dots)");
            return;
        }

        buildBtn.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        resultBox.setVisibility(View.GONE);
        statusView.setTextColor(Ui.SUB);
        statusView.setText("Building APK...");

        final boolean zm = zipMode;
        final Uri src = sourceUri;
        final byte[] icon = iconPng;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final File apk = BuildRunner.run(CreateActivity.this, zm, src, appName, pkg, icon);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onBuilt(apk);
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onFailed(t);
                        }
                    });
                }
            }
        }).start();
    }

    private void onBuilt(File apk) {
        builtApk = apk;
        buildBtn.setEnabled(true);
        progress.setVisibility(View.GONE);
        statusView.setText("");
        resultView.setText("APK ready\n" + apk.getName() + " (" + Formatter.formatFileSize(this, apk.length()) + ")");
        resultBox.setVisibility(View.VISIBLE);
    }

    private void onFailed(Throwable t) {
        buildBtn.setEnabled(true);
        progress.setVisibility(View.GONE);
        statusView.setTextColor(0xFFB91C1C);
        String m = t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
        statusView.setText("Build fail: " + m);
    }

    private void saveCopy() {
        if (builtApk == null) {
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, builtApk.getName());
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            Ui.toast(this, "Save screen khul nahi saki");
        }
    }
}
