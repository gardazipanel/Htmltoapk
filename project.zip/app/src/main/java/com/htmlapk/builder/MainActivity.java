package com.htmlapk.builder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = Ui.screen(this, "HTML to APK", false);
        ScrollView sv = new ScrollView(this);
        root.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 24));
        sv.addView(col);

        col.addView(bigCard("</>", Ui.TEAL, "HTML File to APK", "Convert HTML file to Android APK",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openCreate("html");
                    }
                }), Ui.margins(this, 0, 0, 0, 14));

        col.addView(bigCard("ZIP", 0xFF2E9D4E, "ZIP File to APK", "Convert ZIP (website) to Android APK",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openCreate("zip");
                    }
                }), Ui.margins(this, 0, 0, 0, 14));

        TextView more = Ui.tv(this, "MORE", 15, 0xFF8A94A6, true);
        col.addView(more, Ui.margins(this, 4, 10, 0, 10));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(tile("\u25A6", "My Apps", "See created APKs", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFiles("apk");
            }
        }), tileParams(true));
        row1.addView(tile("\u2193", "Downloads", "APKs & keys", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFiles("key");
            }
        }), tileParams(false));
        col.addView(row1, Ui.margins(this, 0, 0, 0, 12));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(tile("\u2605", "Rate Us", "Support the app", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rate();
            }
        }), tileParams(true));
        row2.addView(tile("i", "How to Use", "Step by step guide", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                howTo();
            }
        }), tileParams(false));
        col.addView(row2, Ui.margins(this, 0, 0, 0, 12));
    }

    private LinearLayout.LayoutParams tileParams(boolean first) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.WRAP, 1f);
        if (first) {
            p.setMargins(0, 0, Ui.dp(this, 6), 0);
        } else {
            p.setMargins(Ui.dp(this, 6), 0, 0, 0);
        }
        return p;
    }

    private View bigCard(String glyph, int color, String title, String sub, View.OnClickListener l) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(Ui.shape(this, Ui.CARD, Ui.BORDER, 1, 24));
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 22), Ui.dp(this, 18), Ui.dp(this, 22));
        card.setClickable(true);
        card.setOnClickListener(l);

        TextView icon = Ui.tv(this, glyph, 17, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(Ui.shape(this, color, 0, 0, 14));
        card.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 18), 0, Ui.dp(this, 8), 0);
        texts.addView(Ui.tv(this, title, 20, Ui.TEXT, true));
        TextView s = Ui.tv(this, sub, 14, Ui.SUB, false);
        s.setPadding(0, Ui.dp(this, 4), 0, 0);
        texts.addView(s);
        card.addView(texts, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));

        TextView chev = Ui.tv(this, "\u203A", 24, color, true);
        chev.setGravity(Gravity.CENTER);
        chev.setBackground(Ui.circle(0x1A0D9488));
        card.addView(chev, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        return card;
    }

    private View tile(String glyph, String title, String sub, View.OnClickListener l) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setBackground(Ui.shape(this, 0xFFF3F8F7, Ui.BORDER, 1, 20));
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16));
        t.setClickable(true);
        t.setOnClickListener(l);

        TextView icon = Ui.tv(this, glyph, 20, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(Ui.circle(Ui.TEAL));
        t.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(Ui.dp(this, 12), 0, 0, 0);
        texts.addView(Ui.tv(this, title, 17, Ui.TEXT, true));
        texts.addView(Ui.tv(this, sub, 12, Ui.SUB, false));
        t.addView(texts, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        return t;
    }

    private void openCreate(String mode) {
        Intent i = new Intent(this, CreateActivity.class);
        i.putExtra("mode", mode);
        startActivity(i);
    }

    private void openFiles(String kind) {
        Intent i = new Intent(this, FilesActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void rate() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
            } catch (Exception ignored) {
                Ui.toast(this, "Store khul nahi saka");
            }
        }
    }

    private void howTo() {
        String msg = "1. 'HTML File to APK' (sirf aik HTML file) ya 'ZIP File to APK' (poori website) chunen.\n\n"
                + "2. ZIP ke andar index.html zaroor honi chahiye. CSS, JS aur images relative path se likhen, "
                + "jaise style.css ya img/logo.png.\n\n"
                + "3. File chunen, app ka naam likhen, chahen to icon bhi chunen.\n\n"
                + "4. BUILD APK dabayen. Kuch seconds ma APK ban jayegi.\n\n"
                + "5. Install dabayen. Pehli dafa 'Install unknown apps' ki ijazat deni hogi.\n\n"
                + "6. Banayi hui APK 'My Apps' ma milti hai. Signing key 'Downloads' ma hoti hai. "
                + "Usay safe rakhen, kyunke app update ke liye wohi key chahiye.";
        new AlertDialog.Builder(this)
                .setTitle("How to Use")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }
}
