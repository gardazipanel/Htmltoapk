package com.htmlapk.builder;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;

import com.android.apksig.ApkSigner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Runs the whole pipeline: template -> patched unsigned apk -> signed apk. */
final class BuildRunner {

    private BuildRunner() {
    }

    static File run(Context ctx, boolean zipMode, final Uri src, String appName, String pkg,
                    byte[] icon) throws Exception {
        File cache = ctx.getCacheDir();
        File tpl = new File(cache, "template.apk");
        InputStream in;
        try {
            in = ctx.getAssets().open("template.apk");
        } catch (IOException e) {
            throw new IOException("template.apk app ke andar nahi hai (build steps dobara dekhein)");
        }
        OutputStream tout = new FileOutputStream(tpl);
        try {
            Ui.copy(in, tout);
        } finally {
            in.close();
            tout.close();
        }

        File unsigned = new File(cache, "unsigned.apk");
        Map<String, String> repl = new HashMap<String, String>();
        repl.put("com.htmlapk.template", pkg);
        repl.put("__APP_NAME__", appName);

        final ContentResolver cr = ctx.getContentResolver();
        ApkBuilder.buildUnsigned(tpl, unsigned, repl, icon, zipMode, new ApkBuilder.Opener() {
            @Override
            public InputStream open() throws IOException {
                InputStream i = cr.openInputStream(src);
                if (i == null) {
                    throw new IOException("File khul nahi saki");
                }
                return i;
            }
        });

        KeyHelper.Keys keys = KeyHelper.load(ctx, pkg);

        File dir = new File(ctx.getFilesDir(), "apks");
        dir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File out = new File(dir, safe(appName) + "_" + stamp + ".apk");

        ApkSigner.SignerConfig cfg = new ApkSigner.SignerConfig.Builder(
                "HTMLAPK", keys.key, Collections.singletonList(keys.cert)).build();
        ApkSigner signer = new ApkSigner.Builder(Collections.singletonList(cfg))
                .setInputApk(unsigned)
                .setOutputApk(out)
                .setMinSdkVersion(21)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setCreatedBy("HTML to APK")
                .build();
        signer.sign();
        unsigned.delete();
        tpl.delete();
        return out;
    }

    private static String safe(String s) {
        String r = s.replaceAll("[^A-Za-z0-9_-]", "_");
        if (r.length() > 40) {
            r = r.substring(0, 40);
        }
        return r.length() == 0 ? "app" : r;
    }
}
