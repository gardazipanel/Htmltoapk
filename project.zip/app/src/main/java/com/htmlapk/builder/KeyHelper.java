package com.htmlapk.builder;

import android.content.Context;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Date;

/** One PKCS12 keystore per package name, kept in the app's private storage. */
final class KeyHelper {

    static final String PASSWORD = "htmlapk123";
    private static final String ALIAS = "key";

    static final class Keys {
        PrivateKey key;
        X509Certificate cert;
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "keys");
        d.mkdirs();
        return d;
    }

    static Keys load(Context c, String pkg) throws Exception {
        File f = new File(dir(c), pkg + ".p12");
        char[] pw = PASSWORD.toCharArray();
        KeyStore ks = KeyStore.getInstance("PKCS12");
        if (f.exists()) {
            InputStream in = new FileInputStream(f);
            try {
                ks.load(in, pw);
            } finally {
                in.close();
            }
        } else {
            ks.load(null, null);
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            X509Certificate cert = makeCert(kp, pkg);
            ks.setKeyEntry(ALIAS, kp.getPrivate(), pw, new Certificate[]{cert});
            OutputStream o = new FileOutputStream(f);
            try {
                ks.store(o, pw);
            } finally {
                o.close();
            }
        }
        Keys k = new Keys();
        k.key = (PrivateKey) ks.getKey(ALIAS, pw);
        k.cert = (X509Certificate) ks.getCertificate(ALIAS);
        if (k.key == null || k.cert == null) {
            throw new IllegalStateException("Key load nahi hui");
        }
        return k;
    }

    private static X509Certificate makeCert(KeyPair kp, String pkg) throws Exception {
        X500Name name = new X500Name("CN=" + pkg + ", O=HTML to APK");
        long now = System.currentTimeMillis();
        Date from = new Date(now - 24L * 60 * 60 * 1000);
        Date to = new Date(now + 10000L * 24 * 60 * 60 * 1000);
        JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), from, to, name, kp.getPublic());
        ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(kp.getPrivate());
        return new JcaX509CertificateConverter().getCertificate(b.build(signer));
    }
}
