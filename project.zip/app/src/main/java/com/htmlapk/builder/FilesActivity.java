package com.htmlapk.builder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.text.format.Formatter;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;

/** Lists created APKs ("My Apps") or signing keys ("Downloads"). */
public class FilesActivity extends Activity {

    private static final int REQ_SAVE = 10;

    private boolean keys;
    private LinearLayout list;
    private File pendingSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        keys = "key".equals(getIntent().getStringExtra("kind"));

        LinearLayout root = Ui.screen(this, keys ? "Downloads" : "My Apps", true);
        ScrollView sv = new ScrollView(this);
        root.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 24));
        sv.addView(list);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private File dir() {
        File d = keys ? KeyHelper.dir(this) : new File(getFilesDir(), "apks");
        d.mkdirs();
        return d;
    }

    private void refresh() {
        list.removeAllViews();

        if (keys) {
            TextView note = Ui.tv(this, "Signing keys (.p12)\nKey password: " + KeyHelper.PASSWORD
                    + "\nIn keys ko safe rakhen. Kisi app ko update karne ke liye wohi key chahiye.",
                    14, Ui.SUB, false);
            note.setPadding(Ui.dp(this, 4), 0, 0, Ui.dp(this, 12));
            list.addView(note);
        }

        File[] files = dir().listFiles();
        if (files == null || files.length == 0) {
            TextView empty = Ui.tv(this, keys ? "Abhi koi key nahi hai." : "Abhi koi APK nahi banayi.",
                    16, Ui.SUB, false);
            empty.setPadding(Ui.dp(this, 4), Ui.dp(this, 24), 0, 0);
            list.addView(empty);
            return;
        }
        Arrays.sort(files, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        for (final File f : files) {
            LinearLayout card = Ui.card(this);
            card.setClickable(true);
            card.addView(Ui.tv(this, f.getName(), 16, Ui.TEXT, true));
            String info = Formatter.formatFileSize(this, f.length()) + "  \u2022  "
                    + DateFormat.format("dd MMM yyyy, HH:mm", new Date(f.lastModified()));
            TextView sub = Ui.tv(this, info, 13, Ui.SUB, false);
            sub.setPadding(0, Ui.dp(this, 4), 0, 0);
            card.addView(sub);
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showActions(f);
                }
            });
            list.addView(card, Ui.margins(this, 0, 0, 0, 10));
        }
    }

    private void showActions(final File f) {
        final String[] items = keys
                ? new String[]{"Save a copy", "Delete"}
                : new String[]{"Install", "Save a copy", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(f.getName())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        String s = items[which];
                        if (s.equals("Install")) {
                            Ui.install(FilesActivity.this, f);
                        } else if (s.equals("Save a copy")) {
                            saveCopy(f);
                        } else {
                            confirmDelete(f);
                        }
                    }
                })
                .show();
    }

    private void confirmDelete(final File f) {
        String msg = keys
                ? "Ye key delete hui to is app ko update nahi kiya ja sakega. Pakka delete karna hai?"
                : "Ye APK delete karni hai?";
        new AlertDialog.Builder(this)
                .setMessage(msg)
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        f.delete();
                        refresh();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveCopy(File f) {
        pendingSave = f;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(keys ? "application/x-pkcs12" : "application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_TITLE, f.getName());
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            Ui.toast(this, "Save screen khul nahi saki");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE || resultCode != RESULT_OK || data == null || data.getData() == null
                || pendingSave == null) {
            return;
        }
        Uri uri = data.getData();
        try {
            InputStream in = new FileInputStream(pendingSave);
            OutputStream out = getContentResolver().openOutputStream(uri);
            try {
                Ui.copy(in, out);
            } finally {
                in.close();
                if (out != null) {
                    out.close();
                }
            }
            Ui.toast(this, "Save ho gayi");
        } catch (Exception e) {
            Ui.toast(this, "Save nahi hui: " + e.getMessage());
        }
    }
}
