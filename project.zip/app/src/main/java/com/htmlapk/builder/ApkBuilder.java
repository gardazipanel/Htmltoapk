package com.htmlapk.builder;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Takes the prebuilt template APK, swaps in the user's website (assets/www),
 * patches app name / package in the manifest and optionally the launcher icon.
 * The result is an UNSIGNED apk; signing happens afterwards.
 */
public final class ApkBuilder {

    public interface Opener {
        InputStream open() throws IOException;
    }

    private static final String WWW = "assets/www/";

    private ApkBuilder() {
    }

    public static void buildUnsigned(File template, File outFile, Map<String, String> manifestReplacements,
                                     byte[] iconPng, boolean zipMode, Opener source) throws IOException {
        String prefix = null;
        if (zipMode) {
            prefix = findSiteRoot(source);
            if (prefix == null) {
                throw new IOException("ZIP ke andar index.html nahi mili");
            }
        }

        CountingOutputStream counter = new CountingOutputStream(
                new BufferedOutputStream(new FileOutputStream(outFile)));
        ZipOutputStream zos = new ZipOutputStream(counter);
        boolean ok = false;
        try {
            ZipFile tz = new ZipFile(template);
            try {
                Enumeration<? extends ZipEntry> en = tz.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    String n = e.getName();
                    if (e.isDirectory() || n.startsWith("META-INF/") || n.startsWith(WWW)) {
                        continue;
                    }
                    byte[] data = readAll(tz.getInputStream(e));
                    if (n.equals("AndroidManifest.xml")) {
                        data = Axml.patch(data, manifestReplacements);
                    } else if (iconPng != null && n.startsWith("res/") && n.endsWith(".png")) {
                        data = iconPng;
                    }
                    if (e.getMethod() == ZipEntry.STORED) {
                        putStored(zos, counter, n, data);
                    } else {
                        putDeflated(zos, n, data);
                    }
                }
            } finally {
                tz.close();
            }

            if (!zipMode) {
                InputStream in = source.open();
                try {
                    putDeflated(zos, WWW + "index.html", readAll(in));
                } finally {
                    in.close();
                }
            } else {
                copySite(zos, source, prefix);
            }

            zos.finish();
            zos.close();
            ok = true;
        } finally {
            if (!ok) {
                try {
                    zos.close();
                } catch (IOException ignored) {
                }
                outFile.delete();
            }
        }
    }

    // ---------- site zip handling ----------

    /** Returns the folder prefix ("" or "site/") that contains the shallowest index.html, or null. */
    static String findSiteRoot(Opener source) throws IOException {
        ZipInputStream zin = new ZipInputStream(new BufferedInputStream(source.open()));
        try {
            ZipEntry e;
            String best = null;
            int bestDepth = Integer.MAX_VALUE;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) {
                    continue;
                }
                String n = clean(e.getName());
                if (n == null) {
                    continue;
                }
                String lower = n.toLowerCase(Locale.ROOT);
                if (lower.equals("index.html") || lower.endsWith("/index.html")) {
                    int depth = 0;
                    for (int i = 0; i < n.length(); i++) {
                        if (n.charAt(i) == '/') {
                            depth++;
                        }
                    }
                    if (depth < bestDepth) {
                        bestDepth = depth;
                        best = n.substring(0, n.length() - "index.html".length());
                    }
                }
            }
            return best;
        } finally {
            zin.close();
        }
    }

    private static void copySite(ZipOutputStream zos, Opener source, String prefix) throws IOException {
        Set<String> used = new HashSet<String>();
        ZipInputStream zin = new ZipInputStream(new BufferedInputStream(source.open()));
        try {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) {
                    continue;
                }
                String n = clean(e.getName());
                if (n == null || !n.startsWith(prefix)) {
                    continue;
                }
                String rel = n.substring(prefix.length());
                if (rel.length() == 0) {
                    continue;
                }
                if (rel.equalsIgnoreCase("index.html")) {
                    rel = "index.html";
                }
                String full = WWW + rel;
                if (!used.add(full)) {
                    continue;
                }
                ZipEntry z = new ZipEntry(full);
                z.setMethod(ZipEntry.DEFLATED);
                zos.putNextEntry(z);
                int r;
                while ((r = zin.read(buf)) > 0) {
                    zos.write(buf, 0, r);
                }
                zos.closeEntry();
            }
        } finally {
            zin.close();
        }
    }

    /** Normalises a zip entry name; returns null for entries that must be skipped. */
    static String clean(String name) {
        String n = name.replace('\\', '/');
        while (n.startsWith("/")) {
            n = n.substring(1);
        }
        if (n.length() == 0) {
            return null;
        }
        if (n.equals("..") || n.startsWith("../") || n.contains("/../") || n.endsWith("/..")) {
            return null;
        }
        if (n.startsWith("__MACOSX/") || n.contains("/__MACOSX/") || n.endsWith(".DS_Store")) {
            return null;
        }
        return n;
    }

    // ---------- zip writing helpers ----------

    private static void putDeflated(ZipOutputStream zos, String name, byte[] data) throws IOException {
        ZipEntry z = new ZipEntry(name);
        z.setMethod(ZipEntry.DEFLATED);
        zos.putNextEntry(z);
        zos.write(data);
        zos.closeEntry();
    }

    /** Stored entry whose data starts on a 4-byte boundary (needed for resources.arsc on Android 11+). */
    private static void putStored(ZipOutputStream zos, CountingOutputStream counter, String name, byte[] data)
            throws IOException {
        zos.closeEntry();
        ZipEntry z = new ZipEntry(name);
        z.setMethod(ZipEntry.STORED);
        z.setSize(data.length);
        z.setCompressedSize(data.length);
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        z.setCrc(crc.getValue());

        int nameLen = name.getBytes("UTF-8").length;
        long dataOffset = counter.count + 30 + nameLen;
        int pad = (int) ((4 - (dataOffset % 4)) % 4);
        if (pad != 0) {
            int extraLen = pad + 4;
            byte[] extra = new byte[extraLen];
            extra[0] = (byte) 0x35; // 0xD935 (same id zipalign uses)
            extra[1] = (byte) 0xD9;
            extra[2] = (byte) ((extraLen - 4) & 0xFF);
            extra[3] = (byte) (((extraLen - 4) >> 8) & 0xFF);
            z.setExtra(extra);
        }
        zos.putNextEntry(z);
        zos.write(data);
        zos.closeEntry();
    }

    static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) {
                o.write(buf, 0, r);
            }
            return o.toByteArray();
        } finally {
            in.close();
        }
    }

    private static final class CountingOutputStream extends OutputStream {
        private final OutputStream out;
        long count;

        CountingOutputStream(OutputStream out) {
            this.out = out;
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }

        @Override
        public void flush() throws IOException {
            out.flush();
        }

        @Override
        public void close() throws IOException {
            out.close();
        }
    }
}
