package com.htmlapk.builder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Minimal patcher for Android binary XML (compiled AndroidManifest.xml).
 * It only rewrites the string pool: every string that exactly equals a key of
 * the replacement map is swapped for the new value. All other chunks refer to
 * strings by index, so they stay untouched.
 */
public final class Axml {

    private static final int FLAG_UTF8 = 0x100;
    private static final Charset UTF16 = Charset.forName("UTF-16LE");
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private Axml() {
    }

    public static byte[] patch(byte[] in, Map<String, String> replacements) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);
        if (in.length < 36 || (b.getShort(0) & 0xFFFF) != 0x0003) {
            throw new IOException("Manifest binary XML nahi hai");
        }
        int fileHeader = b.getShort(2) & 0xFFFF;
        int poolStart = fileHeader;
        if ((b.getShort(poolStart) & 0xFFFF) != 0x0001) {
            throw new IOException("String pool nahi mila");
        }
        int poolHeader = b.getShort(poolStart + 2) & 0xFFFF;
        int poolSize = b.getInt(poolStart + 4);
        int strCount = b.getInt(poolStart + 8);
        int styleCount = b.getInt(poolStart + 12);
        int flags = b.getInt(poolStart + 16);
        int strStart = b.getInt(poolStart + 20);
        boolean utf8 = (flags & FLAG_UTF8) != 0;
        if (styleCount != 0) {
            throw new IOException("Styled strings supported nahi");
        }

        List<String> strings = new ArrayList<String>(strCount);
        int offsetTable = poolStart + poolHeader;
        for (int i = 0; i < strCount; i++) {
            int off = b.getInt(offsetTable + 4 * i);
            int pos = poolStart + strStart + off;
            strings.add(utf8 ? readUtf8(b, pos) : readUtf16(b, pos));
        }

        int replaced = 0;
        for (int i = 0; i < strings.size(); i++) {
            String repl = replacements.get(strings.get(i));
            if (repl != null) {
                strings.set(i, repl);
                replaced++;
            }
        }
        if (replaced < replacements.size()) {
            throw new IOException("Template ma placeholder nahi mila");
        }

        // Re-encode string data
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offsets = new int[strCount];
        for (int i = 0; i < strCount; i++) {
            offsets[i] = data.size();
            byte[] enc = utf8 ? encodeUtf8(strings.get(i)) : encodeUtf16(strings.get(i));
            data.write(enc, 0, enc.length);
        }
        while (data.size() % 4 != 0) {
            data.write(0);
        }

        int newStrStart = poolHeader + 4 * strCount;
        int newPoolSize = newStrStart + data.size();

        ByteBuffer out = ByteBuffer.allocate(fileHeader + newPoolSize + (in.length - (poolStart + poolSize)))
                .order(ByteOrder.LITTLE_ENDIAN);
        out.put(in, 0, fileHeader);
        int newPoolBegin = out.position();
        out.put(in, poolStart, poolHeader);
        out.putInt(newPoolBegin + 4, newPoolSize);
        out.putInt(newPoolBegin + 20, newStrStart);
        out.putInt(newPoolBegin + 24, 0);
        for (int i = 0; i < strCount; i++) {
            out.putInt(offsets[i]);
        }
        out.put(data.toByteArray());
        out.put(in, poolStart + poolSize, in.length - (poolStart + poolSize));
        out.putInt(4, out.capacity());
        return out.array();
    }

    // ---- decoding ----

    private static String readUtf16(ByteBuffer b, int pos) {
        int len = b.getShort(pos) & 0xFFFF;
        int p = pos + 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
            p += 2;
        }
        byte[] raw = new byte[len * 2];
        for (int i = 0; i < raw.length; i++) {
            raw[i] = b.get(p + i);
        }
        return new String(raw, UTF16);
    }

    private static String readUtf8(ByteBuffer b, int pos) {
        int p = pos;
        int charLen = b.get(p++) & 0xFF;
        if ((charLen & 0x80) != 0) {
            charLen = ((charLen & 0x7F) << 8) | (b.get(p++) & 0xFF);
        }
        int byteLen = b.get(p++) & 0xFF;
        if ((byteLen & 0x80) != 0) {
            byteLen = ((byteLen & 0x7F) << 8) | (b.get(p++) & 0xFF);
        }
        byte[] raw = new byte[byteLen];
        for (int i = 0; i < byteLen; i++) {
            raw[i] = b.get(p + i);
        }
        return new String(raw, UTF8);
    }

    // ---- encoding ----

    private static byte[] encodeUtf16(String s) throws IOException {
        int len = s.length();
        if (len > 0x7FFFFFFF) {
            throw new IOException("String bohat lamba");
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (len > 0x7FFF) {
            int hi = ((len >> 16) & 0x7FFF) | 0x8000;
            o.write(hi & 0xFF);
            o.write((hi >> 8) & 0xFF);
            o.write(len & 0xFF);
            o.write((len >> 8) & 0xFF);
        } else {
            o.write(len & 0xFF);
            o.write((len >> 8) & 0xFF);
        }
        byte[] chars = s.getBytes(UTF16);
        o.write(chars, 0, chars.length);
        o.write(0);
        o.write(0);
        return o.toByteArray();
    }

    private static byte[] encodeUtf8(String s) throws IOException {
        byte[] bytes = s.getBytes(UTF8);
        int charLen = s.length();
        if (charLen > 0x7FFF || bytes.length > 0x7FFF) {
            throw new IOException("String bohat lamba");
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        writeLen8(o, charLen);
        writeLen8(o, bytes.length);
        o.write(bytes, 0, bytes.length);
        o.write(0);
        return o.toByteArray();
    }

    private static void writeLen8(ByteArrayOutputStream o, int len) {
        if (len > 0x7F) {
            o.write(((len >> 8) & 0x7F) | 0x80);
            o.write(len & 0xFF);
        } else {
            o.write(len);
        }
    }
}
