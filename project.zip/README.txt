HTML to APK - Android app (source)

Is project ma 2 modules hain:
  template/  -> khali WebView app. Ye "template.apk" ban kar generator app ke andar rakhi jati hai.
  app/       -> HTML to APK app (jis ka interface aap ne dekha). Ye template ko le kar
                aap ki HTML/ZIP andar daalti hai, naam/package/icon badalti hai aur APK sign karti hai.

Build (GitHub Actions ye khud karta hai):
  1) gradle :template:assembleRelease
  2) template/build/outputs/apk/release/*.apk  ->  app/src/main/assets/template.apk
  3) gradle :app:assembleRelease     (APK: app/build/outputs/apk/release/app-release.apk)

Android Studio ma kholna ho to pehle step 1 aur 2 manually karein.
